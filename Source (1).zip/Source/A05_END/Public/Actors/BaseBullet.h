// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BaseBullet.generated.h"

UCLASS()
class A05_END_API ABaseBullet : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ABaseBullet();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	class USphereComponent* SphereComponent;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	class UProjectileMovementComponent* MovementComponent;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	class UStaticMeshComponent* MeshComponent;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Variable")
		FTimerHandle TimerHandle;
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Variable")
		float TimeToDestroy;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Variable")
		float Damage;

	UFUNCTION(BlueprintCallable, Category = "Function")
		virtual void SpecialAttack();

	UFUNCTION(BlueprintCallable, Category = "Function")
		virtual void HandleOverlap(AActor* DamagedActor, UPrimitiveComponent* OtherComp, const FHitResult& SweepResult);

	UFUNCTION()
	void CollisionBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,
		int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
};
