// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Components/ProgressBar.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Components/WidgetSwitcher.h"
#include "BaseUserWidget.generated.h"

/**
 *
 */
UCLASS()
class A05_END_API UBaseUserWidget : public UUserWidget
{
	GENERATED_BODY()

protected:
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
		class UTextBlock* Current;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
		UTextBlock* Max;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
		class UImage* cHair;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
		UImage* cHairL;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
		UImage* Rifle;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
		UImage* Launch;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
		class UProgressBar* HealthBar;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
		class UWidgetSwitcher* cHairS;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
		UWidgetSwitcher* Icon;

	UPROPERTY(BlueprintReadOnly)
		class UMaterialInstanceDynamic* DynamicMaterial;
	UPROPERTY(BlueprintReadOnly)
		TArray<UMaterialInstanceDynamic*> DynamicMaterials;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FName ColorKey;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FLinearColor nColor;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FLinearColor bColor;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FVector Destination;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FVector hPlace;

	bool Hit;

	virtual void NativeConstruct() override;

	UFUNCTION()
	void SetColor(FLinearColor Color);

	virtual void NativeTick(const FGeometry& Geo, float dTime) override;

public:

	UFUNCTION(BlueprintCallable)
		bool GetDestination(FVector& hit, FVector& dPoint) const;

	UFUNCTION(BlueprintCallable)
		virtual void SetHealth(float percent);
	UFUNCTION(BlueprintCallable)
		void SetAmmo(float currentA, float maxA);
	UFUNCTION(BlueprintCallable)
		void SetcHair(int index);
};
