// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Particles/ParticleSystemComponent.h"
#include "Core/EffectInterface.h"
#include "FireEffect.generated.h"

UCLASS()
class A05_END_API AFireEffect : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AFireEffect();

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		UParticleSystemComponent* ParticleSystemComponent;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TSubclassOf<class UDamageType> FireType;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float DPS;
};
