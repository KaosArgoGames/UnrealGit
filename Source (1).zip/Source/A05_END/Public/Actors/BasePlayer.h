// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Actors/BaseCharacter.h"
#include "ICodeInterface.h"
#include "BasePlayer.generated.h"

/**
 * 
 */
UCLASS()
class A05_END_API ABasePlayer : public ABaseCharacter
{
	GENERATED_BODY()
protected:
	void BeginPlay() override;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera")
	class USpringArmComponent* SpringArm;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera|Child")
	class UCameraComponent* Camera;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera|Child")
		class APlayerController* PlayerController;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
		class UBaseUserWidget* HUD;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Variable")
		TSubclassOf<class UBaseUserWidget> GUI;

	void MoveZ(float AxisValue);

	void MoveX(float AxisValue);

	void HandleDeath(float percent) override;

	void BindWaE() override;
public:
	ABasePlayer();
	void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	bool CanPickupHealth() const override;

	bool ShouldPickupHealth() const override;

	void SetRefs() override;

	virtual FRotator GetBaseAimRotation() const override;

	void RemoveUI();

	void Reload() override;

	void Attack() override;
};
