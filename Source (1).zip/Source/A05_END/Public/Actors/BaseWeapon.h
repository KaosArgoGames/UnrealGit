// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BaseWeapon.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FBaseWeaponDelegate);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FBaseWeaponDelegate1, float, current, float, max);

USTRUCT(BlueprintType)
struct FWeaponSI {
	GENERATED_BODY()

		UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TSubclassOf<class URifleAnim> aInstance;
		UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int WeaponIndex;
};

UCLASS()
class A05_END_API ABaseWeapon : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	ABaseWeapon();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Mesh")
		class USkeletalMeshComponent* SkeletalMesh;

	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UFUNCTION(BlueprintCallable, Category = "Function")
		virtual class ABaseBullet* Attack();

	UFUNCTION()
	void AnimationEnded();
	UFUNCTION()
	void OwnerDied();
	UFUNCTION()
	void Reload();
	UFUNCTION()
	void UseAmmo();
	UFUNCTION()
	void RequestReload();

	UFUNCTION(BlueprintCallable, Category = "Function")
		virtual void SpecialAttack();

	UPROPERTY(BlueprintReadOnly, EditAnywhere, Category = "Variable")
		APawn* Pawn;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Variable")
		TSubclassOf<class ABaseBullet> BulletClass;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Variable")
		bool Animating;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Variable")
		bool Dead;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Variable")
		float CurrentAmmo;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Variable")
		float MaxAmmo;
	UFUNCTION(BlueprintCallable, Category = "Function")
		bool CanShoot() const;
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Variable")
		FBaseWeaponDelegate OnAttack;
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Variable")
		FBaseWeaponDelegate1 OnAmmoUpdate;
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Variable")
		FBaseWeaponDelegate OnReloadAnim;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Variable")
		FWeaponSI WeaponSI;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Variable")
		TSubclassOf<class UBaseUserWidget> WidgetClass;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Variable")
		UBaseUserWidget* Widget;
	TArray<UUserWidget*> Widgets;
};
