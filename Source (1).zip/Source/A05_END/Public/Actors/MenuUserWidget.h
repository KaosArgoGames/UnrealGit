// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Actors/TextUserWidget.h"
#include "Core/BaseGameInstance.h"
#include "MenuUserWidget.generated.h"

/**
 * 
 */
UCLASS()
class A05_END_API UMenuUserWidget : public UUserWidget
{
	GENERATED_BODY()
	
public:

	virtual void NativePreConstruct() override;
	virtual void NativeConstruct() override;

	UFUNCTION(BlueprintCallable)
		void OnSClick();
	UFUNCTION(BlueprintCallable)
		void OnQClick();

	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
		class UTextUserWidget* StartButton;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
		UTextUserWidget* QuitButton;
	UPROPERTY(BlueprintReadOnly)
		class UBaseGameInstance* gInstance;
};
