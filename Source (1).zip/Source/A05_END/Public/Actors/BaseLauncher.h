// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Actors/BaseWeapon.h"
#include "BaseLauncher.generated.h"

/**
 * 
 */
UCLASS()
class A05_END_API ABaseLauncher : public ABaseWeapon
{
	GENERATED_BODY()

		public:
			ABaseLauncher();

		UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Variable")
			TArray<class ABaseBullet*> Ammo;

		ABaseBullet* inherit;

		virtual ABaseBullet* Attack() override;

		virtual void SpecialAttack() override;
	
		UFUNCTION()
		void DespawnProjectile(AActor* BulletToDespwan);
};
