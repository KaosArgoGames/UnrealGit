// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "ICodeInterface.h"
#include "Actors/BaseSceneComponent.h"
#include "BaseCharacter.generated.h"

UCLASS(Abstract)
class A05_END_API ABaseCharacter : public ACharacter, public IICodeInterface
{
	GENERATED_BODY()

protected:
	// Sets default values for this character's properties
	ABaseCharacter();

public:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		class UChildActorComponent* ChildActorComponent;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		class UBaseActorComponent* BaseActorComponent;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		class UBaseSceneComponent* SceneComponent;

	UFUNCTION()
		void PlayAttack();

	UFUNCTION()
		void PlayHurt(float percent);

	UFUNCTION()
		void PlayDeath();

	UFUNCTION()
		void AnimationEnded();

	UFUNCTION()
		void OwnerDied();

	UFUNCTION()
		virtual void HandleDeath(float percent);

	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Variable")
		TSubclassOf<class ABaseWeapon> WeaponClass;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Variable")
		TSubclassOf<class ABaseWeapon> cRifle;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Variable")
		TSubclassOf<class ABaseWeapon> cLauncher;

	class ABaseWeapon* Weapon;
	class URifleAnim* AnimBP;

	UFUNCTION()
	virtual void Attack();

	UFUNCTION()
	void SpecialAttack();

	UFUNCTION()
	void Swap();

	UFUNCTION()
	virtual void Reload();

	UFUNCTION()
	virtual void SetRefs();

	UFUNCTION()
	virtual void BindWaE();

	bool CanPickupHealth() const override;
	bool ShouldPickupHealth() const override;
};
