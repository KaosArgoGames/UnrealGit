// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "BaseSceneComponent.generated.h"

UENUM(BlueprintType)
enum class EEffectType : uint8
{
	ET_Fire		UMETA(DisplayName="Fire"),
	NumEffects	UMETA(Hidden)
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class A05_END_API UBaseSceneComponent : public USceneComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UBaseSceneComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	

	void StartEffect(EEffectType Effect, AActor* Causer);

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TSubclassOf<class AFireEffect> FireClass;
};
