// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Components/WidgetSwitcher.h"
#include "Components/VerticalBox.h"
#include "TextUserWidget.h"
#include "Core/BaseGameInstance.h"
#include "ResultsUserWidget.generated.h"

/**
 * 
 */
UCLASS()
class A05_END_API UResultsUserWidget : public UUserWidget
{
	GENERATED_BODY()
	
		void NativePreConstruct() override;

	public:

		UPROPERTY(BlueprintReadOnly, EditAnywhere, Category = "Variable")
			float timeWin = 3.73562f;
		UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
			class UWidgetSwitcher* ResultSwitcher;
		UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
			class UVerticalBox* Buttons;
		UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
			class UTextUserWidget* WBP_Text;
		UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
			UTextUserWidget* WBP_Text1;
		UPROPERTY(BlueprintReadOnly, EditAnywhere, Category = "Variable")
			class UBaseGameInstance* GameInstanceRef;

		UFUNCTION(BlueprintCallable)
			void SetWin();
		UFUNCTION(BlueprintCallable)
			void GoToMenu();
		UFUNCTION(BlueprintCallable)
			void Restart();
};
