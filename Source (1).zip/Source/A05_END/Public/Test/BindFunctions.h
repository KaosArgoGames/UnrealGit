// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BindFunctions.generated.h"

UCLASS()
class A05_END_API ABindFunctions : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ABindFunctions();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UFUNCTION(BlueprintCallable, Category = "Function")
		void BlueprintCallable();
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Function")
		void BlueprintImplementableEvent();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Function")
		void BlueprintNativeEvent();
	virtual void BlueprintNativeEvent_Implementation();

	//Multi Returns
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Function")
	bool MUltiReturnValues(AActor* Actor1, FRotator rotation, AActor*& Actor2, int32& Index);
};
