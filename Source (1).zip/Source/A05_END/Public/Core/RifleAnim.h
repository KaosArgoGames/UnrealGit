// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"
#include "RifleAnim.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FBaseAnimDelegate);

/**
 *
 */
UCLASS()
class A05_END_API URifleAnim : public UAnimInstance
{
	GENERATED_BODY()
public:
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable)
		void PersonaUpdates();
	virtual void PersonaUpdates_Implementation();
	void NativeUpdateAnimation(float DeltaSeconds) override;
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable)
		void PlayAttack();
	virtual void PlayAttack_Implementation();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable)
		void PlayHurt();
	virtual void PlayHurt_Implementation();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable)
		void PlayReload();
	virtual void PlayReload_Implementation();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable)
		void PlayDeath();
	virtual void PlayDeath_Implementation();

	UFUNCTION()
	void Notify();
	UFUNCTION()
	void Reloaded();
	UFUNCTION()
	void DeathEnded();

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float Speed;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float Direction;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool DebugAttack;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool DebugHurt;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool DebugDeath;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool DebugReload;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int DeathIndex;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		UAnimSequenceBase* AttackAsset;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		UAnimSequenceBase* HurtAsset;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		UAnimSequenceBase* ReloadAsset;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<UAnimSequenceBase*> DeathAssets;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		UAnimSequenceBase* CurrentDeath;
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Variable")
		FBaseAnimDelegate OnActionsEnded;
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Variable")
		FBaseAnimDelegate OnReloaded;
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Variable")
		FBaseAnimDelegate OnDeathEnded;
};
