// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "Actors/MenuUserWidget.h"
#include "MenuPlayerController.generated.h"

/**
 *
 */
UCLASS()
class A05_END_API AMenuPlayerController : public APlayerController
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TSubclassOf<class UUserWidget> MMWidgetC;
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
		UMenuUserWidget* MainMenuWidget;

	virtual void BeginPlay() override;
};
