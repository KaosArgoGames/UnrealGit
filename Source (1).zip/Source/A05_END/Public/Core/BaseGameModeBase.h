// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "Actors/ResultsUserWidget.h"
#include "BaseGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class A05_END_API ABaseGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
		void BeginPlay() override;

	public:
		UFUNCTION()
			void RemoveEnemy(AActor* Enemy);
		UFUNCTION()
			void RemovePlayer(AActor* Actor);

		TArray<AActor*> Enemies;
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Variable")
		int numEnemies;
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Variable")
		APawn* Player;
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Variable")
			class UResultsUserWidget* ResultsWidget;
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Variable")
			TSubclassOf<UResultsUserWidget> ResultsWidgetClass;
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Variable")
			class APlayerController* ActiveCont;
};
