// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "Kismet/GameplayStatics.h"
#include "BaseGameInstance.generated.h"

/**
 * 
 */
UCLASS()
class A05_END_API UBaseGameInstance : public UGameInstance
{
	GENERATED_BODY()
	
public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Variable")
		TArray<FName> lvlNames;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Variable")
		int MainMenu = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Variable")
		int Level1 = 1;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Variable")
		int lvlCurrent;

	UFUNCTION(BlueprintCallable)
		void LoadGame();
	UFUNCTION(BlueprintCallable)
		void LoadMenu();
private:
	UFUNCTION(BlueprintCallable)
		void LoadSafe(int lvl);
public:
	UFUNCTION(BlueprintCallable)
		void Quit();
	UFUNCTION(BlueprintCallable)
		void LoadCurrentLevel();
};
