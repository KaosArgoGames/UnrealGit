// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/DamageType.h"
#include "Core/EffectInterface.h"
#include "Actors/BaseSceneComponent.h"
#include "FireDamageType.generated.h"

/**
 * 
 */
UCLASS()
class A05_END_API UFireDamageType : public UDamageType, public IEffectInterface
{
	GENERATED_BODY()
	
		public:
			UFireDamageType();
			void ApplyEffect(AActor* Actor, AActor* Causer) const override;

			UPROPERTY(BlueprintReadWrite, EditAnywhere)
				TSubclassOf<class UActorComponent> SceneClass;
};
