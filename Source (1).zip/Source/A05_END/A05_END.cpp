// Fill out your copyright notice in the Description page of Project Settings.

#include "A05_END.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, A05_END, "A05_END" );
DEFINE_LOG_CATEGORY(Game);