// Fill out your copyright notice in the Description page of Project Settings.


#include "Core/BaseAnimNotify.h"
#include "Core/RifleAnim.h"

void UBaseAnimNotify::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);
	RifleAnim = Cast<URifleAnim>(MeshComp->GetAnimInstance());
	if (RifleAnim != nullptr)
	RifleAnim->OnActionsEnded.Broadcast();
}