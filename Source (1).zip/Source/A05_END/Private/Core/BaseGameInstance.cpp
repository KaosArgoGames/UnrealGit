// Fill out your copyright notice in the Description page of Project Settings.


#include "Core/BaseGameInstance.h"

void UBaseGameInstance::LoadGame()
{
	LoadSafe(Level1);
}

void UBaseGameInstance::Quit()
{
	GetWorld()->GetFirstPlayerController()->ConsoleCommand("quit");
}

void UBaseGameInstance::LoadSafe(int lvl)
{
	if (lvlNames[lvl].IsValid())
	{
		lvlCurrent = lvl;
	}
	UGameplayStatics::OpenLevel(this, lvlNames[lvlCurrent]);
}

void UBaseGameInstance::LoadMenu()
{
	LoadSafe(MainMenu);
}

void UBaseGameInstance::LoadCurrentLevel()
{
	LoadSafe(lvlCurrent);
}