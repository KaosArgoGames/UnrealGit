// Fill out your copyright notice in the Description page of Project Settings.


#include "Core/FireDamageType.h"

UFireDamageType::UFireDamageType() {
}

void UFireDamageType::ApplyEffect(AActor* Actor, AActor* Causer) const {
	UActorComponent* Comp = Actor->GetComponentByClass(SceneClass);
	if (Comp != nullptr) {
		UBaseSceneComponent* SceneComponent = Cast<UBaseSceneComponent>(Comp);
		SceneComponent->StartEffect(EEffectType::ET_Fire, Causer);
	}
}