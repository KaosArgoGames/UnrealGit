// Fill out your copyright notice in the Description page of Project Settings.


#include "Core/BaseGameModeBase.h"
#include "Actors/BaseAI.h"
#include "Actors/BasePlayer.h"
#include <Kismet/GameplayStatics.h>

void ABaseGameModeBase::BeginPlay()
{
	Super::BeginPlay();
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), ABaseAI::StaticClass(), Enemies);
	for (auto Actor : Enemies)
	{
		ABaseAI* Enemy = Cast<ABaseAI>(Actor);
		if (Enemy)
		{
			Enemy->OnDestroyed.AddDynamic(this, &ABaseGameModeBase::RemoveEnemy);
		}
	}
	numEnemies = Enemies.Num();
	Player = Cast<ABasePlayer>(UGameplayStatics::GetActorOfClass(GetWorld(), ABasePlayer::StaticClass()));
	//Player = Cast<ABasePlayer>(Player);
	Player->OnDestroyed.AddDynamic(this, &ABaseGameModeBase::RemovePlayer);
	ActiveCont = Cast<APlayerController>(UGameplayStatics::GetPlayerController(GetWorld(), 0));
	ResultsWidget = CreateWidget<UResultsUserWidget>(ActiveCont, ResultsWidgetClass);
}

void ABaseGameModeBase::RemoveEnemy(AActor* Enemy)
{
	--numEnemies;
	if (numEnemies > 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("Enemies Remaining: %d"), numEnemies);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("You Win!"));
		ResultsWidget->SetWin();
		ResultsWidget->AddToViewport();
		Player->DisableInput(ActiveCont);
		Player->OnDestroyed.RemoveDynamic(this, &ABaseGameModeBase::RemovePlayer);
	    Cast<ABasePlayer>(Player)->RemoveUI();
	}
}

void ABaseGameModeBase::RemovePlayer(AActor* Actor)
{
	ResultsWidget->AddToViewport();
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), ABaseAI::StaticClass(), Enemies);
	for (auto Actor1 : Enemies)
	{
		ABaseAI* Enemy = Cast<ABaseAI>(Actor1);
		if (Enemy)
		{
			Enemy->WhenPlayerDied();
		}
	}
	ActiveCont->bShowMouseCursor = true;
	ActiveCont->SetInputMode(FInputModeUIOnly().SetLockMouseToViewportBehavior(EMouseLockMode::LockAlways));
	Cast<ABasePlayer>(Player)->RemoveUI();
}