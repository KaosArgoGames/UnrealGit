// Fill out your copyright notice in the Description page of Project Settings.


#include "Core/ReloadAnimNotify.h"
#include "Core/RifleAnim.h"

void UReloadAnimNotify::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);
	RifleAnim = Cast<URifleAnim>(MeshComp->GetAnimInstance());
	if (RifleAnim != nullptr)
		RifleAnim->OnReloaded.Broadcast();
}