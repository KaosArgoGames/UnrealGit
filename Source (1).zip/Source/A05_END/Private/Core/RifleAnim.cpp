// Fill out your copyright notice in the Description page of Project Settings.


#include "Core/RifleAnim.h"

void URifleAnim::NativeUpdateAnimation(float DeltaSeconds) {
	Super::NativeUpdateAnimation(DeltaSeconds);

	APawn* Pawn = TryGetPawnOwner();

	if (Pawn != nullptr) {
		FVector Vel = Pawn->GetVelocity();
		Speed = Vel.Size();
		FRotator Rot = Pawn->GetActorRotation();
		if (!Vel.IsNearlyZero())
		{
			FMatrix RotMatrix = FRotationMatrix(Rot);
			FVector ForwardVector = RotMatrix.GetScaledAxis(EAxis::X);
			FVector RightVector = RotMatrix.GetScaledAxis(EAxis::Y);
			FVector NormalizedVel = Vel.GetSafeNormal2D();

			float ForwardCosAngle = FVector::DotProduct(ForwardVector, NormalizedVel);
			float ForwardDeltaDegree = FMath::RadiansToDegrees(FMath::Acos(ForwardCosAngle));

			float RightCosAngle = FVector::DotProduct(RightVector, NormalizedVel);
			if (RightCosAngle < 0)
			{
				ForwardDeltaDegree *= -1;
			}

			Direction = ForwardDeltaDegree;
		}
		else {
			Direction = 0.0f;
			PersonaUpdates();
		}
	}
}

void URifleAnim::PlayAttack_Implementation() {
	PlaySlotAnimationAsDynamicMontage(AttackAsset, "Action");
}

void URifleAnim::PlayHurt_Implementation() {
	if (IsPlayingSlotAnimation(HurtAsset, "Hurt"))
		PlaySlotAnimationAsDynamicMontage(HurtAsset, "Hurt");
}

void URifleAnim::PlayDeath_Implementation() {
	DeathIndex = FMath::RandRange(0, DeathAssets.Num() - 1);
	CurrentDeath = DeathAssets[DeathIndex];
	FTimerHandle DeathTimer;
	GetWorld()->GetTimerManager().SetTimer(DeathTimer, this, &URifleAnim::DeathEnded, CurrentDeath->GetPlayLength(), false);
}

void URifleAnim::PersonaUpdates_Implementation() {
	if (DebugAttack) {
		DebugAttack = false;
		PlayAttack();
	}
	if (DebugHurt) {
		DebugHurt = false;
		PlayHurt();
	}
	if (DebugDeath) {
		DebugDeath = false;
		PlayDeath();
	}
	if (DebugReload) {
		DebugReload = false;
		PlayReload();
	}
}

void URifleAnim::Notify() {
	OnActionsEnded.Broadcast();
}

void URifleAnim::DeathEnded() {
	OnDeathEnded.Broadcast();
}

void URifleAnim::PlayReload_Implementation() {
	PlaySlotAnimationAsDynamicMontage(ReloadAsset, "Action");
	Reloaded();
}

void URifleAnim::Reloaded() {
	OnReloaded.Broadcast();
}