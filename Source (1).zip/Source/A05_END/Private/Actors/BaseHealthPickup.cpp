// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/BaseHealthPickup.h"
#include "Particles/ParticleSystemComponent.h"
#include <Kismet/GameplayStatics.h>
#include <Actors/BasePlayer.h>
#include "Actors/ICodeInterface.h"

ABaseHealthPickup::ABaseHealthPickup() {
	ParticleSystemComponent = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("ParticleSystemComponent"));
	ParticleSystemComponent->SetupAttachment(RootComponent);
	ParticleSystemComponent->SetWorldLocation(FVector(0.f, 0.f, -30.f));
	ParticleSystemComponent->SetWorldScale3D(FVector(0.6f, 0.6f, 0.50f));
	HealthAmount = -5.f;
}

void ABaseHealthPickup::HandlePickup(AActor* OtherActor, FHitResult SweepResult) {
	Super::HandlePickup(OtherActor, SweepResult);
	UGameplayStatics::ApplyDamage(OtherActor, HealthAmount, nullptr, this, nullptr);
	PostPickup();
}

void ABaseHealthPickup::PostPickup() {
	Super::PostPickup();
	ParticleSystemComponent->Deactivate();
}

bool ABaseHealthPickup::CanPickup(AActor* OtherActor) const {
	OtherActor = Cast<ABasePlayer>(OtherActor);
	if (OtherActor == Cast<ABasePlayer>(OtherActor))
		return Cast<ABasePlayer>(OtherActor)->CanPickupHealth();
	return false;
}

bool ABaseHealthPickup::ShouldPickup(AActor* OtherActor) const {
	OtherActor = Cast<ABasePlayer>(OtherActor);
	if (OtherActor == Cast<ABasePlayer>(OtherActor))
		return Cast<ABasePlayer>(OtherActor)->ShouldPickupHealth();
	return false;
}

void ABaseHealthPickup::HandleNoPickup() {
	UGameplayStatics::PlaySoundAtLocation(this, InvalidSound, GetActorLocation());
}