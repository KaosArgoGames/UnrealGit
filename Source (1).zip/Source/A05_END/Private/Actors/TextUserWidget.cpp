// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/TextUserWidget.h"

void UTextUserWidget::NativeConstruct()
{
	Super::NativeConstruct();

	Info->SetText(Guess);

	BackgroundForButton->OnClicked.AddDynamic(this, &UTextUserWidget::OnClick);
}

void UTextUserWidget::OnClick()
{
	OnClicked.Broadcast();
}

#if WITH_EDITOR
void UTextUserWidget::OnDesignerChanged(const FDesignerChangedEventArgs& EventArgs)
{
	Super::OnDesignerChanged(EventArgs);
	if (Info)
		Info->SetText(Guess);
}
#endif