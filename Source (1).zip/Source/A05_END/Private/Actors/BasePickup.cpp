// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/BasePickup.h"
#include "Components/BoxComponent.h"

// Sets default values
ABasePickup::ABasePickup()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;
	BoxComponent = CreateDefaultSubobject<UBoxComponent>(TEXT("BoxComponent"));
	SetRootComponent(BoxComponent);
	BoxComponent->SetGenerateOverlapEvents(true);
	BoxComponent->SetCollisionProfileName(TEXT("Pickup"));
	BoxComponent->SetWorldScale3D(FVector(1.6f, 1.6f, 1.6f));
}

// Called when the game starts or when spawned
void ABasePickup::BeginPlay()
{
	Super::BeginPlay();
	BoxComponent->OnComponentBeginOverlap.AddDynamic(this, &ABasePickup::CollisionBeginOverlap);
}

void ABasePickup::HandlePickup(AActor* OtherActor, FHitResult SweepResult) {
	
}

void ABasePickup::PostPickup() {
	K2_DestroyActor();
}

void ABasePickup::CollisionBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,
	int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult) {
	if (CanPickup(OtherActor))
		if (ShouldPickup(OtherActor)) {
			HandlePickup(OtherActor, SweepResult);
		}
		else {
			HandleNoPickup();
		}
}

bool ABasePickup::CanPickup(AActor* OtherActor) const {
	return true;
}

bool ABasePickup::ShouldPickup(AActor* OtherActor) const {
	return true;
}

void ABasePickup::HandleNoPickup() {
}