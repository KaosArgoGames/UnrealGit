// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/FireEffect.h"
#include <Kismet/GameplayStatics.h>
#include <Core/FireDamageType.h>

// Sets default values
AFireEffect::AFireEffect()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 1;
	ParticleSystemComponent = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("ParticleSystemComponent"));
	ParticleSystemComponent->SetupAttachment(RootComponent);
	DPS = 0.25f;
	InitialLifeSpan = 2.6903f;
}

// Called every frame
void AFireEffect::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	DPS *= DeltaTime;
	UGameplayStatics::ApplyDamage(GetAttachParentActor(), DPS, nullptr, GetOwner(), FireType);
}