// Fill out your copyright notice in the Description page of Project Settings.

#include "Actors/BaseAI.h"
#include "Core/RifleAnim.h"

ABaseAI::ABaseAI()
{
	PrimaryActorTick.bCanEverTick = false;
	PrimaryActorTick.bStartWithTickEnabled = false;
	AutoPossessAI = EAutoPossessAI::PlacedInWorldOrSpawned;
}

void ABaseAI::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	Attack();
}

void ABaseAI::BindWaE()
{
	Super::BindWaE();
	AnimBP->OnDeathEnded.AddDynamic(this, &AActor::K2_DestroyActor);
}

void ABaseAI::WhenPlayerDied()
{
	SetActorTickEnabled(false);
}