// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/BaseWeapon.h"
#include <Actors/BaseBullet.h>
#include "Actors/BaseUserWidget.h"
#include <Blueprint/WidgetBlueprintLibrary.h>

// Sets default values
ABaseWeapon::ABaseWeapon()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

	SkeletalMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("SkeletalMesh"));
	SetRootComponent(SkeletalMesh);
	SkeletalMesh->SetGenerateOverlapEvents(false);
	SkeletalMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	SkeletalMesh->SetCollisionProfileName(TEXT("NoCollision"));
	Animating = false;
	MaxAmmo = 4;
}

// Called when the game starts or when spawned
void ABaseWeapon::BeginPlay()
{
	Pawn = Cast<APawn>(GetParentActor());
	Super::BeginPlay();
	Reload();
}

// Called every frame
void ABaseWeapon::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

ABaseBullet* ABaseWeapon::Attack() {
	if (CanShoot()) {
		FActorSpawnParameters Spawn;
		Spawn.Owner = Pawn->GetController();
		Spawn.Instigator = Pawn;
		ABaseBullet* Bullet = GetWorld()->SpawnActor<ABaseBullet>(BulletClass, SkeletalMesh->GetSocketLocation("MuzzleFlashSocket"), Pawn->GetBaseAimRotation(), Spawn);
		Animating = true;
		OnAttack.Broadcast();
		UseAmmo();
		return Bullet;
	}
	else
		return nullptr;
}

void ABaseWeapon::AnimationEnded() {
	Animating = false;
}

void ABaseWeapon::OwnerDied() {
	Dead = true;
}

bool ABaseWeapon::CanShoot() const {
	return !Animating && !Dead && CurrentAmmo > 0;
}

void ABaseWeapon::SpecialAttack() {
}

void ABaseWeapon::Reload() {
	CurrentAmmo = MaxAmmo;
	OnAmmoUpdate.Broadcast(CurrentAmmo, MaxAmmo);
}

void ABaseWeapon::UseAmmo() {
	CurrentAmmo = FMath::Clamp(--CurrentAmmo, 0.0f, MaxAmmo);
	OnAmmoUpdate.Broadcast(CurrentAmmo, MaxAmmo);
}

void ABaseWeapon::RequestReload() {
	if (!Animating)
	{
		Animating = true;
		OnReloadAnim.Broadcast();
	}
}