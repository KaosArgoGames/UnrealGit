// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/BasePlayer.h"
#include "Actors/BaseWeapon.h"
#include "Actors/BaseUserWidget.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/PlayerController.h"
#include "Components/CapsuleComponent.h"
#include "Actors/BaseActorComponent.h"
#include "Blueprint/UserWidget.h"
#include "Core/RifleAnim.h"

ABasePlayer::ABasePlayer() {
	SpringArm = CreateDefaultSubobject<USpringArmComponent>("SpringArm");
	SpringArm->SetupAttachment(RootComponent);
	SpringArm->bUsePawnControlRotation = true;
	SpringArm->SetRelativeLocation(FVector(0.0f, 80.0f, 90.0f));
	SpringArm->TargetArmLength = 210.0f;
	Camera = CreateDefaultSubobject<UCameraComponent>("Camera");
	Camera->SetupAttachment(SpringArm);
	Camera->bCameraMeshHiddenInGame = true;
}

void ABasePlayer::BeginPlay() {
	Super::BeginPlay();
	PlayerController = Cast<APlayerController>(GetController());
	HUD->AddToViewport();
	BaseActorComponent->OnDamaged.AddDynamic(HUD, &UBaseUserWidget::SetHealth);
	BaseActorComponent->OnDeath.AddDynamic(HUD, &UBaseUserWidget::SetHealth);
	BaseActorComponent->OnHealed.AddDynamic(HUD, &UBaseUserWidget::SetHealth);
	Weapon->OnAmmoUpdate.AddDynamic(HUD, &UBaseUserWidget::SetAmmo);
	HUD->SetcHair(Weapon->WeaponSI.WeaponIndex);
	HUD->SetAmmo(Weapon->CurrentAmmo, Weapon->MaxAmmo);
}

void ABasePlayer::SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) {
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	//Rotate
	PlayerInputComponent->BindAxis("TurnTo", this, &APawn::AddControllerYawInput);
	PlayerInputComponent->BindAxis("LookTo", this, &APawn::AddControllerPitchInput);
	//Move
	PlayerInputComponent->BindAxis("MoveZ", this, &ABasePlayer::MoveZ);
	PlayerInputComponent->BindAxis("MoveX", this, &ABasePlayer::MoveX);

	PlayerInputComponent->BindAction("StandardAttack", IE_Pressed, this, &ABasePlayer::Attack);
	PlayerInputComponent->BindAction("SpecialAttack", IE_Released, this, &ABasePlayer::SpecialAttack);
	PlayerInputComponent->BindAction("SwitchWeapon", IE_Pressed, this, &ABasePlayer::Swap);
	PlayerInputComponent->BindAction("Reload", IE_Pressed, this, &ABasePlayer::Reload);
}

void ABasePlayer::MoveZ(float AxisValue) {
	FRotator MakeRotator = FRotator(0.0f, GetControlRotation().Yaw, 0.0f);

	AddMovementInput(MakeRotator.Vector(), AxisValue);
}

void ABasePlayer::MoveX(float AxisValue) {
	//Next time use GetActor"   "
	FRotator MakeRotator = FRotator(0.0f, GetControlRotation().Yaw, 0.0f);
	FVector LR_Dir = FRotationMatrix(MakeRotator).GetScaledAxis(EAxis::Y);

	AddMovementInput(LR_Dir, AxisValue);
}

void ABasePlayer::HandleDeath(float percent) {
	Super::HandleDeath(percent);
	DisableInput(PlayerController);
}

bool ABasePlayer::CanPickupHealth() const {
	return true;
}

bool ABasePlayer::ShouldPickupHealth() const {
	return !BaseActorComponent->IsFullHealth();
}

void ABasePlayer::SetRefs() {
	Super::SetRefs();
	PlayerController = Cast<APlayerController>(GetController());
	if (!HUD)
	{
		HUD = CreateWidget<UBaseUserWidget>(GetWorld(), GUI);
	}
	HUD->SetcHair(Weapon->WeaponSI.WeaponIndex);
}

FRotator ABasePlayer::GetBaseAimRotation() const {
	FVector Landed;
	FVector End;
	FVector Destination;
	if (HUD->GetDestination(Landed, End))
	{
		Destination = Landed;
	}
	else
	{
		Destination = End;
	}

	Destination -= Weapon->SkeletalMesh->GetSocketLocation("MuzzleFlashSocket");

	return Destination.Rotation();
}

void ABasePlayer::BindWaE() {
	Super::BindWaE();
	AnimBP->OnDeathEnded.AddDynamic(this, &AActor::K2_DestroyActor);
	HUD->SetAmmo(Weapon->CurrentAmmo, Weapon->MaxAmmo);
}

void ABasePlayer::RemoveUI() {
	HUD->RemoveFromParent();
}

void ABasePlayer::Reload() {
	Super::Reload();
	HUD->SetAmmo(Weapon->MaxAmmo, Weapon->MaxAmmo);
}

void ABasePlayer::Attack() {
	Super::Attack();
	HUD->SetAmmo(Weapon->CurrentAmmo, Weapon->MaxAmmo);
}