// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/BaseBullet.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SphereComponent.h"

// Sets default values
ABaseBullet::ABaseBullet()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;
	PrimaryActorTick.bStartWithTickEnabled = false;


	SphereComponent = CreateDefaultSubobject<USphereComponent>(TEXT("SphereComponent"));
	SetRootComponent(SphereComponent);
	SphereComponent->OnComponentBeginOverlap.AddDynamic(this, &ABaseBullet::CollisionBeginOverlap);
	SphereComponent->SetWorldScale3D(FVector(0.2f, 0.2f, 0.2f));

	MovementComponent = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("MovementComponent"));
	MovementComponent->ProjectileGravityScale = 0.0f;
	MovementComponent->InitialSpeed = 1800.0f;
	MovementComponent->MaxSpeed = 2000.0f;

	MeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MeshComponent"));
	const ConstructorHelpers::FObjectFinder<UStaticMesh> MeshComponentAsset(TEXT("/Engine/EngineMeshes/Sphere.Sphere"));
	MeshComponent->SetStaticMesh(MeshComponentAsset.Object);
	MeshComponent->SetMaterial(0, ConstructorHelpers::FObjectFinder<UMaterialInterface>(TEXT("/Game/Art/M_FlatColor.M_FlatColor")).Object);
	MeshComponent->SetupAttachment(GetRootComponent());
	MeshComponent->SetWorldScale3D(FVector(0.2f, 0.2f, 0.2f));
	MeshComponent->SetGenerateOverlapEvents(false);
	MeshComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	MeshComponent->SetCollisionProfileName(TEXT("NoCollision"));

	TimeToDestroy = 1.2788987f;
	Damage = 1.0f;
}

// Called when the game starts or when spawned
void ABaseBullet::BeginPlay()
{
	Super::BeginPlay();
	GetWorld()->GetTimerManager().SetTimer(TimerHandle, this, &ABaseBullet::K2_DestroyActor, TimeToDestroy);
}

// Called every frame
void ABaseBullet::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void ABaseBullet::CollisionBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult) {
	HandleOverlap(OtherActor, OtherComp, SweepResult);
}

void ABaseBullet::SpecialAttack() {
}

void ABaseBullet::HandleOverlap(AActor* OtherActor, UPrimitiveComponent* OtherComp, const FHitResult& SweepResult) {
	OtherActor->TakeDamage(Damage, FDamageEvent(), GetInstigatorController(), GetInstigator());
	GetWorld()->DestroyActor(this);
}