// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/ICodeInterface.h"

// Add default functionality here for any IICodeInterface functions that are not pure virtual.