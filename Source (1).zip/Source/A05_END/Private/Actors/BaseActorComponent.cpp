// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/BaseActorComponent.h"
#include "Core/FireDamageType.h"

// Sets default values for this component's properties
UBaseActorComponent::UBaseActorComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = false;
	MaxHealth = 5.0f;
}


// Called when the game starts
void UBaseActorComponent::BeginPlay()
{
	Super::BeginPlay();
	IniHealth();
	GetOwner()->OnTakeAnyDamage.AddDynamic(this, &UBaseActorComponent::DamageTaken);
}


// Called every frame
void UBaseActorComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

}

void UBaseActorComponent::IniHealth() {
	CurrentHealth = MaxHealth;
}

void UBaseActorComponent::DamageTaken(AActor* DamagedActor, float Damage, const class UDamageType* DamageType, class AController* InstigatedBy, AActor* DamageCauser) {
	const UFireDamageType* myType = Cast<UFireDamageType>(DamageType);
	if (myType != nullptr)
		myType->ApplyEffect(DamagedActor, DamageCauser);

	CurrentHealth = FMath::Clamp(CurrentHealth - Damage, 0.0f, MaxHealth);
	percent = CurrentHealth / MaxHealth;
	if (CurrentHealth > 0.0f) {
		OnDamaged.Broadcast(percent);
		if (Damage < 0.0f)
			OnHealed.Broadcast(percent);
	}
	else {
		OnDamaged.Clear();
		GetOwner()->OnTakeAnyDamage.Clear();
		OnDeath.Broadcast(percent);
	}
}

bool UBaseActorComponent::IsFullHealth() const {
	if (CurrentHealth / MaxHealth > 0.99)
		return true;
	return false;
}