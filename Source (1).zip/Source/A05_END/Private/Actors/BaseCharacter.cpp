// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/BaseCharacter.h"
#include "Components/ChildActorComponent.h"
#include <Actors/BaseWeapon.h>
#include <Core/RifleAnim.h>
#include "Actors/BaseActorComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/CapsuleComponent.h"
#include "EngineUtils.h"
#include "Actors/ICodeInterface.h"

// Sets default values
ABaseCharacter::ABaseCharacter()
{
	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;
	GetMesh()->SetGenerateOverlapEvents(true);
	GetMesh()->SetWorldRotation(FRotator(0.0f, -90.0f, 0.0f));
	GetMesh()->SetWorldLocation(FVector(0.0f, 0.0f, -90.0f));

	ChildActorComponent = CreateDefaultSubobject<UChildActorComponent>(TEXT("ChildActorComponent"));
	ChildActorComponent->SetupAttachment(GetMesh(), FName("WeaponTransform"));
	BaseActorComponent = CreateDefaultSubobject<UBaseActorComponent>(TEXT("BaseActorComponent"));
	SceneComponent = CreateDefaultSubobject<UBaseSceneComponent>(TEXT("SceneComponent"));
	SceneComponent->SetupAttachment(GetMesh(), FName("SceneTransform"));
}

// Called when the game starts or when spawned
void ABaseCharacter::BeginPlay()
{
	Super::BeginPlay();
	SetRefs();
	BindWaE();
	BaseActorComponent->OnDeath.AddDynamic(this, &ABaseCharacter::HandleDeath);
	Weapon->Reload();
}

// Called every frame
void ABaseCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void ABaseCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

void ABaseCharacter::Attack() {
	Weapon->Attack();
}

void ABaseCharacter::PlayAttack() {
	AnimBP->PlayAttack();
}

void ABaseCharacter::PlayHurt(float percent) {
	AnimBP->PlayHurt();
}

void ABaseCharacter::PlayDeath() {
	AnimBP->PlayDeath();
}

void ABaseCharacter::AnimationEnded() {
	Weapon->AnimationEnded();
}

void ABaseCharacter::OwnerDied() {
	Weapon->OwnerDied();
}

void ABaseCharacter::HandleDeath(float percent) {
	GetCharacterMovement()->StopMovementImmediately();
	GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	GetMesh()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	AnimBP->PlayDeath();
	Weapon->OwnerDied();
}

bool ABaseCharacter::CanPickupHealth() const {
	return false;
}

bool ABaseCharacter::ShouldPickupHealth() const {
	return false;
}

void ABaseCharacter::SpecialAttack() {
	Weapon->SpecialAttack();
}

void ABaseCharacter::Swap() {
	if (WeaponClass == cLauncher)
		WeaponClass = cRifle;
	else
		WeaponClass = cLauncher;
	SetRefs();
	BindWaE();
	Weapon->Reload();
}

void ABaseCharacter::SetRefs() {
	ChildActorComponent->SetChildActorClass(WeaponClass);
	Weapon = Cast<ABaseWeapon>(ChildActorComponent->GetChildActor());
	GetMesh()->SetAnimInstanceClass(Weapon->WeaponSI.aInstance);
	AnimBP = Cast<URifleAnim>(GetMesh()->GetAnimInstance());
}

void ABaseCharacter::BindWaE() {
	BaseActorComponent->OnDamaged.AddDynamic(this, &ABaseCharacter::PlayHurt);
	Weapon->OnAttack.AddDynamic(this, &ABaseCharacter::PlayAttack);
	AnimBP->OnActionsEnded.AddDynamic(this, &ABaseCharacter::AnimationEnded);
	Weapon->OnReloadAnim.AddDynamic(AnimBP, &URifleAnim::PlayReload);
	AnimBP->OnReloaded.AddDynamic(Weapon, &ABaseWeapon::RequestReload);
}

void ABaseCharacter::Reload() {
	Weapon->RequestReload();
}