// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/MenuUserWidget.h"

void UMenuUserWidget::NativePreConstruct()
{
	gInstance = Cast<UBaseGameInstance>(GetGameInstance());
}

void UMenuUserWidget::NativeConstruct()
{
	Super::NativeConstruct();
	StartButton->OnClicked.AddDynamic(this, &UMenuUserWidget::OnSClick);
	QuitButton->OnClicked.AddDynamic(this, &UMenuUserWidget::OnQClick);
}

void UMenuUserWidget::OnSClick()
{
	gInstance->LoadGame();
}

void UMenuUserWidget::OnQClick()
{
	gInstance->Quit();
}
