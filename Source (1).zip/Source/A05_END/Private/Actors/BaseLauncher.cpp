// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/BaseLauncher.h"
#include "Actors/BaseStickyBomb.h"
#include "Actors/BaseBullet.h"

ABaseLauncher::ABaseLauncher() {
	MaxAmmo = 5;
}

void ABaseLauncher::SpecialAttack() {
	for (int i = Ammo.Num() - 1; i >= 0; --i) {
		Ammo[i]->SpecialAttack();
	}
	Ammo.Empty();
}

ABaseBullet* ABaseLauncher::Attack() {
	inherit = Super::Attack();
	if (inherit != nullptr) {
		Ammo.Add(inherit);
		inherit->OnDestroyed.AddDynamic(this, &ABaseLauncher::DespawnProjectile);
		return inherit;
	}
	return inherit;
}

void ABaseLauncher::DespawnProjectile(AActor* BulletToDespwan) {
	ABaseBullet* tBullet = Cast<ABaseBullet>(BulletToDespwan);
	if (tBullet != nullptr) {
		Ammo.Remove(tBullet);
	}
}