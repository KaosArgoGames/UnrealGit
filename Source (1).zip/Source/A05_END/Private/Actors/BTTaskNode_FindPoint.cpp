// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/BTTaskNode_FindPoint.h"
#include <NavigationSystem.h>
#include <AIController.h>
#include <BehaviorTree/BlackboardComponent.h>
#include <BehaviorTree/Tasks/BTTask_BlueprintBase.h>

UBTTaskNode_FindPoint::UBTTaskNode_FindPoint()
{
	NodeName = TEXT("FindPoint");
}

void UBTTaskNode_FindPoint::ReceiveExecuteAI(AAIController* OwnerController, APawn* ControlledPawn)
{
	UNavigationSystemV1* NavSystem = UNavigationSystemV1::GetNavigationSystem(GetWorld());
	FNavLocation RandomPoint;
	if (NavSystem->GetRandomPointInNavigableRadius(ControlledPawn->GetActorLocation(), Radius, RandomPoint))
	{
		OwnerController->GetBlackboardComponent()->SetValueAsVector(TargetKey.SelectedKeyName, RandomPoint.Location);
	}
}