// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/BaseStickyBomb.h"
#include "Components/SphereComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Kismet/GameplayStatics.h"

ABaseStickyBomb::ABaseStickyBomb() {
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	MeshComponent->SetMaterial(0, ConstructorHelpers::FObjectFinder<UMaterialInterface>(TEXT("MaterialInstanceConstant'/Game/Art/MI_FlatPurple.MI_FlatPurple'")).Object);
	MeshComponent->SetWorldScale3D(FVector(0.3f, 0.3f, 0.3f));
	SphereComponent->SetWorldScale3D(FVector(0.3f, 0.3f, 0.3f));

	Damage = 3.f;
	AOE = 603.987653543f;
}

void ABaseStickyBomb::HandleOverlap(AActor* DamagedActor, UPrimitiveComponent* OtherComp, const FHitResult& SweepResult) {
	USkeletalMeshComponent* smComponent = Cast<USkeletalMeshComponent>(OtherComp);
	if (smComponent != nullptr)
	{
		MovementComponent->StopMovementImmediately();
		SetActorEnableCollision(false);
		TeleportTo(SweepResult.ImpactPoint, GetActorRotation());
		AttachToComponent(smComponent, FAttachmentTransformRules::KeepWorldTransform, SweepResult.BoneName);
		GetWorldTimerManager().ClearTimer(TimerHandle);
		TimerHandle.Invalidate();

	}
	else
	{
		switch (OtherComp->GetCollisionObjectType())
		{
		case ECC_WorldStatic:
			MovementComponent->StopMovementImmediately();
			GetWorldTimerManager().ClearTimer(TimerHandle);
			TimerHandle.Invalidate();
			TeleportTo(SweepResult.Location, GetActorRotation());
			SphereComponent->OnComponentBeginOverlap.RemoveDynamic(this, &ABaseBullet::CollisionBeginOverlap);
			break;
		}
	}
}

void ABaseStickyBomb::SpecialAttack() {
	UGameplayStatics::ApplyRadialDamage(GetWorld(), Damage, GetActorLocation(), AOE, nullptr, TArray<AActor*>(), this);
	Destroy();
}