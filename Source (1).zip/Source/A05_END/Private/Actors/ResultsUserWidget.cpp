// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/ResultsUserWidget.h"

void UResultsUserWidget::NativePreConstruct()
{
	Super::NativePreConstruct();
	GameInstanceRef = Cast<UBaseGameInstance>(GetGameInstance());
	WBP_Text->OnClicked.AddDynamic(this, &UResultsUserWidget::Restart);
	WBP_Text1->OnClicked.AddDynamic(this, &UResultsUserWidget::GoToMenu);
}

void UResultsUserWidget::SetWin()
{
	Buttons->SetVisibility(ESlateVisibility::Hidden);
	ResultSwitcher->SetActiveWidgetIndex(1);
	FTimerHandle UnusedHandle;
	GetWorld()->GetTimerManager().SetTimer(UnusedHandle, this, &UResultsUserWidget::GoToMenu, timeWin, false);
}

void UResultsUserWidget::GoToMenu()
{
	GameInstanceRef->LoadMenu();
}

void UResultsUserWidget::Restart()
{
	GameInstanceRef->LoadCurrentLevel();
}