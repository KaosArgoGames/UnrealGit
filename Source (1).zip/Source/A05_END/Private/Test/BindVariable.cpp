// Fill out your copyright notice in the Description page of Project Settings.


#include "Test/BindVariable.h"
#include "../../A05_END.h"
#include "Components/SphereComponent.h"

// Sets default values
ABindVariable::ABindVariable()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	EditAnywhere = 0.42f;
	VisibleInstanceOnlyOdd = 3;

	SphereComponent = CreateDefaultSubobject<USphereComponent>(TEXT("SphereComponent"));
	SetRootComponent(SphereComponent);
	if (GetOwner() != nullptr)
	{
		SphereComponent->OnComponentHit.AddDynamic(this, &ABindVariable::BoundFunction);
		OnTestVariable.AddDynamic(this, &ABindVariable::TestFunction);
		OnTestVariable.Broadcast(this);
	}
}

// Called when the game starts or when spawned
void ABindVariable::BeginPlay()
{
	Super::BeginPlay();
	UE_LOG(Game, Error, TEXT("Actor's Name is %s"), *GetName());
	UE_LOG(Game, Warning, TEXT("Int is %d and float is %f"), VisibleInstanceOnlyOdd, EditAnywhere);
	UE_LOG(Game, Display, TEXT("Vel %s"), *GetVelocity().ToString());

	FTimerHandle Handle;
	if (GetWorld() != nullptr)
	GetWorld()->GetTimerManager().SetTimer(Handle, this, &ABindVariable::K2_DestroyActor, 2.5f);

	AActor* Base = this;
	ABindVariable* Child = Cast<ABindVariable>(Base);
	if (Child == nullptr) {
		UE_LOG(Game, Error, TEXT("Cannot Upcast"));
	}

	if (ClassType != nullptr) {
		AActor* Actor = GetWorld()->SpawnActor<AActor>(ClassType, GetActorTransform());
	}
	else {
		UE_LOG(Game, Error, TEXT("Please set ClassType"));
	}
}

// Called every frame
void ABindVariable::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void ABindVariable::K2_DestroyActor() {
	UE_LOG(Game, Error, TEXT("Time's Up"));
	Super::K2_DestroyActor();
}

void ABindVariable::BoundFunction(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit) {

}

void ABindVariable::TestFunction(AActor* Other) {

}