// Fill out your copyright notice in the Description page of Project Settings.


#include "Test/BindDefaultPawn.h"
#include "../../A05_END.h"

// Sets default values
ABindDefaultPawn::ABindDefaultPawn()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ABindDefaultPawn::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ABindDefaultPawn::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void ABindDefaultPawn::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	PlayerInputComponent->BindAction("StandardAttack", EInputEvent::IE_Pressed, this, &ABindDefaultPawn::InputHappened);
}

FVector ABindDefaultPawn::Pure() const {
	return FVector(1.0f, 2.0f, 3.0f);
}

void ABindDefaultPawn::InputHappened() {
	UE_LOG(Game, Error, TEXT("Input"));
}