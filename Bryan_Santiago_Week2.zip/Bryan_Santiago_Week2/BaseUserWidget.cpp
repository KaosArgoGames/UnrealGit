// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/BaseUserWidget.h"
#include "Components/Image.h"
#include <Blueprint/SlateBlueprintLibrary.h>
#include <Kismet/KismetSystemLibrary.h>

void UBaseUserWidget::NativeConstruct()
{
	Super::NativeConstruct();
	DynamicMaterial = cHair->GetDynamicMaterial();

	cHair->SetBrushFromMaterial(DynamicMaterial);

	SetColor(nColor);
}

void UBaseUserWidget::SetColor(FLinearColor Color)
{
	DynamicMaterial->SetVectorParameterValue(ColorKey, Color);
}

void UBaseUserWidget::NativeTick(const FGeometry& Geo, float dTime)
{
	Super::NativeTick(Geo, dTime);
	FVector2D PositionPixel;
	FVector2D PositionPort;
	FGeometry Geom = cHair->GetCachedGeometry();
	FVector PositionGlobal;
	FVector DirectionGlobal;
	FHitResult hResult;
	FVector2D Size = Geom.GetAbsoluteSize();
	TArray<TEnumAsByte<EObjectTypeQuery>> Objects{ UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_WorldStatic),
		UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_Pawn)};
	TArray<AActor*> ActorsToIgnore{ GetOwningPlayerPawn() };

	Size /= 2.f;
	USlateBlueprintLibrary::LocalToViewport(GetWorld(), Geom, FVector2D(0, 0), PositionPixel, PositionPort);
	PositionPixel += Size;
	GetOwningPlayer()->DeprojectScreenPositionToWorld(PositionPixel.X, PositionPixel.Y, PositionGlobal, DirectionGlobal);
	Destination = PositionGlobal + (DirectionGlobal * 100000);
	Hit = UKismetSystemLibrary::LineTraceSingleForObjects(GetWorld(), PositionGlobal, Destination, Objects, false, ActorsToIgnore, EDrawDebugTrace::None, hResult, true);

	if (Hit)
	{
		hPlace = hResult.Location;
		APawn* Pawn = Cast<APawn>(hResult.Actor);
		if (Pawn)
		{
			SetColor(bColor);
		}
		else
		{
			SetColor(nColor);
		}
	}
	else
	{
		SetColor(nColor);
	}
}

bool UBaseUserWidget::GetDestination(FVector& hit, FVector& dPoint) const {
	hit = hPlace;
	dPoint = Destination;
	return Hit;
}