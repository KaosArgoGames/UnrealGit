// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Actors/BasePickup.h"
#include "BaseFirePickup.generated.h"

/**
 *
 */
UCLASS()
class A05_END_API ABaseFirePickup : public ABasePickup
{
	GENERATED_BODY()

public:
	ABaseFirePickup();

	virtual void HandlePickup(AActor* OtherActor, FHitResult SweepResult) override;

	virtual void PostPickup() override;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		UParticleSystemComponent* ParticleSystemComponent;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float BaseDamage;
};
