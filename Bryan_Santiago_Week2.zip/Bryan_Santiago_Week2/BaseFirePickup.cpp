// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/BaseFirePickup.h"
#include "Particles/ParticleSystemComponent.h"
#include <Kismet/GameplayStatics.h>

ABaseFirePickup::ABaseFirePickup() {
	ParticleSystemComponent = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("ParticleSystemComponent"));
	ParticleSystemComponent->SetupAttachment(RootComponent);
	ParticleSystemComponent->SetWorldLocation(FVector(0.f, 0.f, -30.f));
	ParticleSystemComponent->SetWorldScale3D(FVector(0.4f, 0.4f, 0.25f));
	BaseDamage = 1.f;
}

void ABaseFirePickup::HandlePickup(AActor* OtherActor, FHitResult SweepResult) {
	Super::HandlePickup(OtherActor, SweepResult);
	UGameplayStatics::ApplyDamage(OtherActor, BaseDamage, nullptr, this, nullptr);
}

void ABaseFirePickup::PostPickup() {
}